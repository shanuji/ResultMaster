import 'dart:io';

import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  static final AppDatabase instance = AppDatabase._init();
  static Database? _database;

  AppDatabase._init();

  static Future<Database> safeInit() async {
    if (instance._database != null) return instance._database!;

    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'result_master.db');
    final file = File(path);

    if (await file.exists()) {
      try {
        final backupDir = await getApplicationDocumentsDirectory();
        final timestamp = DateTime.now().millisecondsSinceEpoch;
        final backupPath =
            join(backupDir.path, 'result_master_backup_$timestamp.db');
        await file.copy(backupPath);
        print('Database securely backed up to: $backupPath');
      } catch (e) {
        throw Exception(
          'CRITICAL: Filesystem database backup failed. '
          'Initialization aborted to prevent data loss. Error: $e',
        );
      }
    }

    instance._database = await openDatabase(
      path,
      version: 5,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON;');
      },
      onCreate: instance._createDB,
      onUpgrade: instance._upgradeDB,
    );

    return instance._database!;
  }

  Future<Database> get database async {
    if (_database != null) return _database!;
    return safeInit();
  }

  Future<void> _createDB(Database db, int version) async {
    await _executeV5Schema(db);
    final now = DateTime.now().toIso8601String();

    await db.insert('migration_logs', {
      'source_schema': 'fresh',
      'source_version': 0,
      'target_version': version,
      'status': 'completed',
      'started_at': now,
      'completed_at': now,
      'marks_migrated': 0,
      'promotions_migrated': 0,
    });
  }

  Future<void> _executeV5Schema(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS migration_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source_schema TEXT NOT NULL,
        source_version INTEGER NOT NULL,
        target_version INTEGER NOT NULL,
        status TEXT NOT NULL,
        started_at TEXT NOT NULL,
        completed_at TEXT,
        marks_migrated INTEGER NOT NULL DEFAULT 0,
        promotions_migrated INTEGER NOT NULL DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS class_registers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        class_register_id INTEGER NOT NULL,
        roll_number TEXT NOT NULL,
        student_name TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (class_register_id)
          REFERENCES class_registers (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS workbooks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        academic_year TEXT,
        class_name TEXT NOT NULL,
        section TEXT,
        examination_name TEXT NOT NULL,
        student_source_type TEXT,
        class_register_id INTEGER,
        created_at TEXT NOT NULL,
        FOREIGN KEY (class_register_id)
          REFERENCES class_registers (id) ON DELETE SET NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS workbook_terms (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        workbook_id INTEGER NOT NULL,
        term_name TEXT NOT NULL,
        FOREIGN KEY (workbook_id)
          REFERENCES workbooks (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS workbook_students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        workbook_id INTEGER NOT NULL,
        student_id INTEGER,
        roll_number TEXT NOT NULL,
        student_name TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (workbook_id)
          REFERENCES workbooks (id) ON DELETE CASCADE,
        FOREIGN KEY (student_id)
          REFERENCES students (id) ON DELETE SET NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS workbook_subjects (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        workbook_id INTEGER NOT NULL,
        subject_name TEXT NOT NULL,
        display_order INTEGER NOT NULL DEFAULT 0,
        maximum_marks REAL NOT NULL,
        passing_marks REAL NOT NULL,
        include_in_percentage INTEGER NOT NULL DEFAULT 1,
        include_in_pass_fail INTEGER NOT NULL DEFAULT 1,
        theme_color INTEGER NOT NULL DEFAULT 4278248955,
        FOREIGN KEY (workbook_id)
          REFERENCES workbooks (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS subject_components (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject_id INTEGER NOT NULL,
        component_name TEXT NOT NULL,
        display_order INTEGER NOT NULL DEFAULT 0,
        maximum_marks REAL NOT NULL,
        passing_marks REAL NOT NULL,
        is_total INTEGER NOT NULL DEFAULT 0,
        is_editable INTEGER NOT NULL DEFAULT 1,
        FOREIGN KEY (subject_id)
          REFERENCES workbook_subjects (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS pass_criteria (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        workbook_id INTEGER NOT NULL,
        criteria_type TEXT NOT NULL,
        passing_value REAL NOT NULL,
        FOREIGN KEY (workbook_id)
          REFERENCES workbooks (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS workbook_tabs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        workbook_id INTEGER NOT NULL,
        tab_name TEXT NOT NULL,
        display_order INTEGER NOT NULL DEFAULT 0,
        is_visible INTEGER NOT NULL DEFAULT 1,
        FOREIGN KEY (workbook_id)
          REFERENCES workbooks (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS workbook_marks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        workbook_id INTEGER NOT NULL,
        term_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        component_id INTEGER NOT NULL,
        marks TEXT NOT NULL,
        UNIQUE(workbook_id, term_id, student_id, component_id),
        FOREIGN KEY (workbook_id)
          REFERENCES workbooks (id) ON DELETE CASCADE,
        FOREIGN KEY (term_id)
          REFERENCES workbook_terms (id) ON DELETE CASCADE,
        FOREIGN KEY (student_id)
          REFERENCES workbook_students (id) ON DELETE CASCADE,
        FOREIGN KEY (component_id)
          REFERENCES subject_components (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS workbook_term_promotions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        workbook_id INTEGER NOT NULL,
        term_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        subject_id INTEGER NOT NULL,
        is_promoted INTEGER NOT NULL,
        UNIQUE(workbook_id, term_id, student_id, subject_id),
        FOREIGN KEY (workbook_id)
          REFERENCES workbooks (id) ON DELETE CASCADE,
        FOREIGN KEY (term_id)
          REFERENCES workbook_terms (id) ON DELETE CASCADE,
        FOREIGN KEY (student_id)
          REFERENCES workbook_students (id) ON DELETE CASCADE,
        FOREIGN KEY (subject_id)
          REFERENCES workbook_subjects (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE IF NOT EXISTS workbook_overall_promotions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        workbook_id INTEGER NOT NULL,
        student_id INTEGER NOT NULL,
        is_promoted INTEGER NOT NULL,
        UNIQUE(workbook_id, student_id),
        FOREIGN KEY (workbook_id)
          REFERENCES workbooks (id) ON DELETE CASCADE,
        FOREIGN KEY (student_id)
          REFERENCES workbook_students (id) ON DELETE CASCADE
      )
    ''');
  }

  Future<void> _upgradeDB(
    Database db,
    int oldVersion,
    int newVersion,
  ) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS migration_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source_schema TEXT NOT NULL,
        source_version INTEGER NOT NULL,
        target_version INTEGER NOT NULL,
        status TEXT NOT NULL,
        started_at TEXT NOT NULL,
        completed_at TEXT,
        marks_migrated INTEGER NOT NULL DEFAULT 0,
        promotions_migrated INTEGER NOT NULL DEFAULT 0
      )
    ''');

    final logs = await db.query(
      'migration_logs',
      where: 'target_version = ?',
      whereArgs: [newVersion],
    );

    final hasCompleted = logs.any((log) => log['status'] == 'completed');
    final hasStarted = logs.any((log) => log['status'] == 'started');

    if (hasCompleted) return;

    if (hasStarted) {
      throw Exception(
        "FATAL: Detected a previously interrupted migration "
        "(status='started'). Cannot proceed safely. Restore from backup.",
      );
    }

    final startTime = DateTime.now().toIso8601String();

    final tablesRaw = await db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type='table'",
    );
    final tableNames =
        tablesRaw.map((t) => t['name'] as String).toList();

    if (!tableNames.contains('workbooks')) {
      await _executeV5Schema(db);
      await db.insert('migration_logs', {
        'source_schema': 'empty',
        'source_version': oldVersion,
        'target_version': newVersion,
        'status': 'completed',
        'started_at': startTime,
        'completed_at': DateTime.now().toIso8601String(),
        'marks_migrated': 0,
        'promotions_migrated': 0,
      });
      return;
    }

    if (tableNames.contains('legacy_workbooks')) {
      throw Exception(
        "FATAL: legacy_workbooks exists but no completed migration log "
        "was found. Restore from backup.",
      );
    }

    final pragmaWb =
        await db.rawQuery("PRAGMA table_info('workbooks')");
    final hasTitle =
        pragmaWb.any((col) => col['name'] == 'title');
    final hasClassName =
        pragmaWb.any((col) => col['name'] == 'class_name');

    final logId = await db.insert('migration_logs', {
      'source_schema': hasClassName ? 'modern_v2' : 'legacy_v4',
      'source_version': oldVersion,
      'target_version': newVersion,
      'status': 'started',
      'started_at': startTime,
      'marks_migrated': 0,
      'promotions_migrated': 0,
    });

    if (hasTitle && !hasClassName) {
      await _migrateLegacyV4(db, oldVersion, newVersion, logId);
    } else if (hasClassName) {
      await _migrateModernV2(
        db,
        oldVersion,
        newVersion,
        logId,
        tableNames,
      );
    } else {
      throw Exception("FATAL: Unrecognized database schema. Aborting.");
    }
  }

  Future<void> _migrateLegacyV4(
    Database db,
    int oldV,
    int newV,
    int logId,
  ) async {
    final tables = (await db.rawQuery(
      "SELECT name FROM sqlite_master WHERE type='table'",
    )).map((t) => t['name'] as String).toList();

    final renameTargets = <String, String>{
      'workbooks': 'legacy_workbooks',
      'terms': 'legacy_terms',
      'students': 'legacy_students',
      'subjects': 'legacy_subjects',
      'subject_components': 'legacy_subject_components',
      'student_marks': 'legacy_student_marks',
      'term_promotions': 'legacy_term_promotions',
      'overall_promotions': 'legacy_overall_promotions',
    };

    for (final entry in renameTargets.entries) {
      if (tables.contains(entry.key) &&
          !tables.contains(entry.value)) {
        await db.execute(
          'ALTER TABLE ${entry.key} RENAME TO ${entry.value}',
        );
      }
    }

    await _executeV5Schema(db);

    final oldWbIdToNewWbId = <int, int>{};
    final oldTermIdToNewTermId = <int, int>{};
    final oldSubIdToNewSubId = <int, int>{};
    final oldCompIdToNewCompId = <int, int>{};
    final wbRollToNewStudentId = <String, int>{};

    final legacyWb = await db.query('legacy_workbooks');

    for (final w in legacyWb) {
      final newId = await db.insert('workbooks', {
        'academic_year': '',
        'class_name': w['title'],
        'section': '',
        'examination_name': w['title'],
        'student_source_type': 'legacy',
        'class_register_id': null,
        'created_at': w['created_at'],
      });
      oldWbIdToNewWbId[w['id'] as int] = newId;
    }

    final legacyTerms = await db.query('legacy_terms');
    for (final t in legacyTerms) {
      final newWbId = oldWbIdToNewWbId[t['workbook_id'] as int];
      if (newWbId != null) {
        final newId = await db.insert('workbook_terms', {
          'workbook_id': newWbId,
          'term_name': t['name'],
        });
        oldTermIdToNewTermId[t['id'] as int] = newId;
      }
    }

    final legacyStudents = await db.query('legacy_students');
    for (final s in legacyStudents) {
      final newWbId = oldWbIdToNewWbId[s['workbook_id'] as int];
      if (newWbId != null) {
        final rollStr = s['roll_no'].toString();
        final newId = await db.insert('workbook_students', {
          'workbook_id': newWbId,
          'student_id': null,
          'roll_number': rollStr,
          'student_name': s['name'],
          'created_at': DateTime.now().toIso8601String(),
        });
        wbRollToNewStudentId["${newWbId}_$rollStr"] = newId;
      }
    }

    final legacySubs = await db.query('legacy_subjects');
    for (final sub in legacySubs) {
      final newWbId = oldWbIdToNewWbId[sub['workbook_id'] as int];
      if (newWbId != null) {
        final newId = await db.insert('workbook_subjects', {
          'workbook_id': newWbId,
          'subject_name': sub['name'],
          'display_order': 0,
          'maximum_marks': sub['max_marks'],
          'passing_marks': sub['passing_marks'],
          'include_in_percentage': sub['include_in_pass_fail'],
          'include_in_pass_fail': sub['include_in_pass_fail'],
          'theme_color': sub['theme_color'] ?? 4278248955,
        });
        oldSubIdToNewSubId[sub['id'] as int] = newId;
      }
    }

    final legacyComps =
        await db.query('legacy_subject_components');
    final subjectsWithComps = <int>{};

    for (final c in legacyComps) {
      final oldSubId = c['subject_id'] as int;
      subjectsWithComps.add(oldSubId);

      final newSubId = oldSubIdToNewSubId[oldSubId];
      if (newSubId != null) {
        final newId = await db.insert('subject_components', {
          'subject_id': newSubId,
          'component_name': c['name'],
          'display_order': 0,
          'maximum_marks': c['max_marks'],
          'passing_marks': c['passing_marks'],
          'is_total': 0,
          'is_editable': 1,
        });
        oldCompIdToNewCompId[c['id'] as int] = newId;
      }
    }

    for (final sub in legacySubs) {
      final oldSubId = sub['id'] as int;
      final newSubId = oldSubIdToNewSubId[oldSubId];

      if (newSubId != null &&
          !subjectsWithComps.contains(oldSubId)) {
        await db.insert('subject_components', {
          'subject_id': newSubId,
          'component_name': 'Marks',
          'display_order': 0,
          'maximum_marks': sub['max_marks'],
          'passing_marks': sub['passing_marks'],
          'is_total': 0,
          'is_editable': 1,
        });
      }
    }

    int mMigrated = 0;
    int mUnmatched = 0;
    int mDuplicated = 0;
    int mInvalid = 0;
    int mAmbiguous = 0;

    final legacyMarks =
        await db.query('legacy_student_marks');
    final allComps = await db.query('subject_components');
    final allSubjects = await db.query('workbook_subjects');

    final newSubIdToName = <int, String>{
      for (final s in allSubjects)
        s['id'] as int: s['subject_name'] as String,
    };

    final compKeyToNewId = <String, int>{};

    for (final c in allComps) {
      final cId = c['id'] as int;
      final sId = c['subject_id'] as int;
      final sName = newSubIdToName[sId] ?? '';
      final cName = c['component_name'] as String;
      final subject =
          allSubjects.firstWhere((e) => e['id'] == sId);
      final wbId = subject['workbook_id'] as int;

      final keys = <String>[
        "${wbId}_$cName",
        "${wbId}_${sName}_$cName",
      ];

      if (cName == 'Marks') {
        keys.add("${wbId}_$sName");
      }

      for (final key in keys) {
        compKeyToNewId[key] =
            compKeyToNewId.containsKey(key) ? -1 : cId;
      }
    }

    for (final m in legacyMarks) {
      if (m['mark_value'] == null ||
          m['mark_key'] == null) {
        mInvalid++;
        continue;
      }

      final newTermId =
          oldTermIdToNewTermId[m['term_id'] as int];

      if (newTermId == null) {
        mUnmatched++;
        continue;
      }

      final oldWbId = legacyTerms
          .firstWhere((t) => t['id'] == m['term_id'])['workbook_id'] as int;
      final newWbId = oldWbIdToNewWbId[oldWbId];

      final newSId =
          wbRollToNewStudentId["${newWbId}_${m['roll_no']}"];
      final newCId =
          compKeyToNewId["${newWbId}_${m['mark_key']}"];

      if (newCId == -1) {
        mAmbiguous++;
        continue;
      }

      if (newSId == null || newCId == null) {
        mUnmatched++;
        continue;
      }

      try {
        await db.insert('workbook_marks', {
          'workbook_id': newWbId,
          'term_id': newTermId,
          'student_id': newSId,
          'component_id': newCId,
          'marks': m['mark_value'],
        });
        mMigrated++;
      } catch (_) {
        mDuplicated++;
      }
    }

    if (mUnmatched > 0 ||
        mDuplicated > 0 ||
        mInvalid > 0 ||
        mAmbiguous > 0 ||
        mMigrated != legacyMarks.length) {
      throw Exception(
        "FATAL: Mark validation failed. "
        "M:$mMigrated/${legacyMarks.length}, "
        "U:$mUnmatched, D:$mDuplicated, "
        "I:$mInvalid, A:$mAmbiguous.",
      );
    }

    int pMigrated = 0;
    int pUnmatched = 0;
    int pDuplicated = 0;
    int pInvalid = 0;

    if (tables.contains('term_promotions')) {
      final legacyTermPromos =
          await db.query('legacy_term_promotions');

      for (final p in legacyTermPromos) {
        if (p['is_promoted'] == null) {
          pInvalid++;
          continue;
        }

        final newTermId =
            oldTermIdToNewTermId[p['term_id'] as int];

        if (newTermId == null) {
          pUnmatched++;
          continue;
        }

        final oldWbId = legacyTerms
            .firstWhere((t) => t['id'] == p['term_id'])['workbook_id'] as int;
        final newWbId = oldWbIdToNewWbId[oldWbId];
        final newSId =
            wbRollToNewStudentId["${newWbId}_${p['roll_no']}"];

        final subMatch = allSubjects.where(
          (s) =>
              s['workbook_id'] == newWbId &&
              s['subject_name'] == p['subject_name'],
        );

        if (newSId == null || subMatch.isEmpty) {
          pUnmatched++;
          continue;
        }

        try {
          await db.insert('workbook_term_promotions', {
            'workbook_id': newWbId,
            'term_id': newTermId,
            'student_id': newSId,
            'subject_id': subMatch.first['id'],
            'is_promoted': p['is_promoted'],
          });
          pMigrated++;
        } catch (_) {
          pDuplicated++;
        }
      }

      if (pMigrated != legacyTermPromos.length) {
        pInvalid++;
      }
    }

    if (tables.contains('overall_promotions')) {
      final legacyOverall =
          await db.query('legacy_overall_promotions');
      final expectedOverall = legacyOverall.length;
      final initialPMigrated = pMigrated;

      for (final o in legacyOverall) {
        if (o['is_promoted'] == null) {
          pInvalid++;
          continue;
        }

        final newWbId =
            oldWbIdToNewWbId[o['workbook_id'] as int];
        final newSId =
            wbRollToNewStudentId["${newWbId}_${o['roll_no']}"];

        if (newSId == null || newWbId == null) {
          pUnmatched++;
          continue;
        }

        try {
          await db.insert('workbook_overall_promotions', {
            'workbook_id': newWbId,
            'student_id': newSId,
            'is_promoted': o['is_promoted'],
          });
          pMigrated++;
        } catch (_) {
          pDuplicated++;
        }
      }

      if ((pMigrated - initialPMigrated) != expectedOverall) {
        pInvalid++;
      }
    }

    if (pUnmatched > 0 ||
        pDuplicated > 0 ||
        pInvalid > 0) {
      throw Exception(
        "FATAL: Promotion validation failed. "
        "U:$pUnmatched, D:$pDuplicated, I:$pInvalid.",
      );
    }

    final newWbCount = Sqflite.firstIntValue(
      await db.rawQuery('SELECT COUNT(*) FROM workbooks'),
    );
    final newStudCount = Sqflite.firstIntValue(
      await db.rawQuery(
        'SELECT COUNT(*) FROM workbook_students',
      ),
    );

    if (newWbCount != legacyWb.length ||
        newStudCount != legacyStudents.length) {
      throw Exception(
        "FATAL: Entity conservation count mismatch.",
      );
    }

    await db.update(
      'migration_logs',
      {
        'status': 'completed',
        'completed_at': DateTime.now().toIso8601String(),
        'marks_migrated': mMigrated,
        'promotions_migrated': pMigrated,
      },
      where: 'id = ?',
      whereArgs: [logId],
    );
  }

  Future<void> _migrateModernV2(
    Database db,
    int oldV,
    int newV,
    int logId,
    List<String> tables,
  ) async {
    bool requiresMarkRebuild = false;

    if (tables.contains('workbook_marks')) {
      final pragmaMarks =
          await db.rawQuery("PRAGMA table_info('workbook_marks')");
      requiresMarkRebuild =
          !pragmaMarks.any((c) => c['name'] == 'term_id');

      if (requiresMarkRebuild) {
        await db.execute(
          'ALTER TABLE workbook_marks '
          'RENAME TO legacy_modern_workbook_marks',
        );
      }
    }

    await _executeV5Schema(db);

    int mMigrated = 0;
    int mUnmatched = 0;
    int mDuplicated = 0;
    int mInvalid = 0;

    if (requiresMarkRebuild) {
      final legacyModernMarks =
          await db.query('legacy_modern_workbook_marks');

      final valWb = await db.query('workbooks');
      final valStud = await db.query('workbook_students');
      final valComp = await db.query('subject_components');

      final validWbs = {
        for (final w in valWb) w['id'] as int,
      };
      final validStudents = {
        for (final s in valStud) s['id'] as int,
      };
      final validComps = {
        for (final c in valComp) c['id'] as int,
      };

      final existingTerms =
          await db.query('workbook_terms');
      final wbToDefaultTerm = <int, int>{};

      for (final t in existingTerms) {
        final wId = t['workbook_id'] as int;
        wbToDefaultTerm.putIfAbsent(
          wId,
          () => t['id'] as int,
        );
      }

      for (final wId in validWbs) {
        if (!wbToDefaultTerm.containsKey(wId)) {
          final tId = await db.insert('workbook_terms', {
            'workbook_id': wId,
            'term_name': 'Default Term',
          });
          wbToDefaultTerm[wId] = tId;
        }
      }

      for (final m in legacyModernMarks) {
        if (m['marks'] == null) {
          mInvalid++;
          continue;
        }

        final wbId = m['workbook_id'] as int;
        final sId = m['student_id'] as int;
        final cId = m['component_id'] as int;

        if (!validWbs.contains(wbId) ||
            !validStudents.contains(sId) ||
            !validComps.contains(cId)) {
          mUnmatched++;
          continue;
        }

        final termId = wbToDefaultTerm[wbId]!;

        try {
          await db.insert('workbook_marks', {
            'workbook_id': wbId,
            'term_id': termId,
            'student_id': sId,
            'component_id': cId,
            'marks': m['marks'],
          });
          mMigrated++;
        } catch (_) {
          mDuplicated++;
        }
      }

      if (mUnmatched > 0 ||
          mDuplicated > 0 ||
          mInvalid > 0 ||
          mMigrated != legacyModernMarks.length) {
        throw Exception(
          "FATAL: Modern V2 Mark validation failed. "
          "M:$mMigrated/${legacyModernMarks.length}, "
          "U:$mUnmatched, D:$mDuplicated, I:$mInvalid.",
        );
      }
    }

    await db.update(
      'migration_logs',
      {
        'status': 'completed',
        'completed_at': DateTime.now().toIso8601String(),
        'marks_migrated': mMigrated,
        'promotions_migrated': 0,
      },
      where: 'id = ?',
      whereArgs: [logId],
    );
  }
}
