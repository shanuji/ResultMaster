import 'package:flutter/material.dart';
import 'package:sqflite/sqflite.dart';

import '../../../../core/database/app_database.dart';
import '../../../../models/data_models.dart';
import '../../domain/entities/result_workbook.dart' as domain;
import '../../domain/repositories/result_workbook_repository.dart';

/// Single persistence bridge for the ResultMaster workbook UI.
///
/// AppDatabase owns schema/migrations. This repository owns relational CRUD and
/// converts SQLite rows into the UI/domain contracts.
class SqliteResultWorkbookRepository implements ResultWorkbookRepository {
  final AppDatabase _appDatabase;

  SqliteResultWorkbookRepository({AppDatabase? appDatabase})
      : _appDatabase = appDatabase ?? AppDatabase.instance;

  Future<Database> get _db async => _appDatabase.database;

  @override
  Future<List<domain.Student>> getClassRegisterStudents(int classRegisterId) async {
    final db = await _db;
    final rows = await db.query(
      'students',
      where: 'class_register_id = ?',
      whereArgs: [classRegisterId],
      orderBy: 'roll_number ASC',
    );
    return rows
        .map((r) => domain.Student(
              id: r['id'] as int,
              rollNumber: int.tryParse(r['roll_number'].toString()) ?? 0,
              name: r['student_name'] as String,
            ))
        .toList();
  }

  @override
  Future<List<domain.WorkbookSummary>> listWorkbooks() async {
    final db = await _db;
    final rows = await db.rawQuery('''
      SELECT
        w.id,
        COALESCE(w.academic_year, '') AS academic_year,
        w.class_name,
        COALESCE(w.section, '') AS section,
        w.examination_name,
        (SELECT COUNT(*) FROM workbook_students ws WHERE ws.workbook_id = w.id) AS student_count,
        (SELECT COUNT(*) FROM workbook_subjects s WHERE s.workbook_id = w.id) AS subject_count
      FROM workbooks w
      ORDER BY w.id DESC
    ''');
    return rows.map(_summaryFromRow).toList();
  }

  domain.WorkbookSummary _summaryFromRow(Map<String, dynamic> row) =>
      domain.WorkbookSummary(
        id: row['id'] as int,
        academicYear: (row['academic_year'] ?? '').toString(),
        className: row['class_name'] as String,
        section: (row['section'] ?? '').toString(),
        examinationName: row['examination_name'] as String,
        studentCount: (row['student_count'] as num?)?.toInt() ?? 0,
        subjectCount: (row['subject_count'] as num?)?.toInt() ?? 0,
      );

  @override
  Future<domain.OpenedWorkbook> openWorkbook(int workbookId) async {
    final summaries = await listWorkbooks();
    final summary = summaries.firstWhere((w) => w.id == workbookId);
    final db = await _db;

    final terms = (await getWorkbookTerms(workbookId))
        .map((t) => domain.WorkbookTerm(
              id: t.id,
              workbookId: t.workbookId,
              name: t.name,
            ))
        .toList();

    final studentsRaw = await db.query(
      'workbook_students',
      where: 'workbook_id = ?',
      whereArgs: [workbookId],
      orderBy: 'roll_number ASC',
    );
    final students = studentsRaw
        .map((r) => domain.Student(
              id: r['id'] as int,
              rollNumber: int.tryParse(r['roll_number'].toString()) ?? 0,
              name: r['student_name'] as String,
            ))
        .toList();

    final subjectRows = await getWorkbookSubjectsWithComponents(workbookId);
    final subjectMap = <int, domain.WorkbookSubject>{};
    for (final row in subjectRows) {
      final subjectId = row['subject_id'] as int;
      final subject = subjectMap.putIfAbsent(
        subjectId,
        () => domain.WorkbookSubject(
          id: subjectId,
          name: row['subject_name'] as String,
          displayOrder: row['subject_order'] as int,
          components: [],
        ),
      );
      if (row['component_id'] != null) {
        subject.components.add(domain.WorkbookComponent(
          id: row['component_id'] as int,
          name: row['component_name'] as String,
          displayOrder: row['component_order'] as int,
          isTotal: (row['is_total'] as int) == 1,
          isEditable: (row['is_editable'] as int) == 1,
        ));
      }
    }

    final markRows = await db.query(
      'workbook_marks',
      where: 'workbook_id = ?',
      whereArgs: [workbookId],
    );
    final marks = markRows
        .map((r) => domain.WorkbookMark(
              termId: r['term_id'] as int,
              studentId: r['student_id'] as int,
              componentId: r['component_id'] as int,
              marks: double.tryParse(r['marks'].toString()),
            ))
        .toList();

    return domain.OpenedWorkbook(
      summary: summary,
      terms: terms,
      students: students,
      subjects: subjectMap.values.toList(),
      passCriteria: const [],
      marks: marks,
    );
  }

  @override
  Future<domain.CreatedWorkbook> createWorkbook(domain.ResultWorkbookDraft draft) async {
    final db = await _db;
    final now = DateTime.now().toIso8601String();
    final workbookId = await db.insert('workbooks', {
      'academic_year': draft.academicYear,
      'class_name': draft.className,
      'section': draft.section,
      'examination_name': draft.examinationName,
      'student_source_type': draft.studentSourceType.name,
      'class_register_id': draft.classRegisterId,
      'created_at': now,
    });

    await createTerm(workbookId, 'Term 1');
    for (var i = 0; i < draft.newStudents.length; i++) {
      final s = draft.newStudents[i];
      await db.insert('workbook_students', {
        'workbook_id': workbookId,
        'student_id': null,
        'roll_number': s.rollNumber.toString(),
        'student_name': s.name,
        'created_at': now,
      });
    }

    for (var i = 0; i < draft.subjects.length; i++) {
      final subject = draft.subjects[i];
      final subjectId = await db.insert('workbook_subjects', {
        'workbook_id': workbookId,
        'subject_name': subject.name,
        'display_order': i,
        'maximum_marks': subject.maximumMarks,
        'passing_marks': subject.passingMarks,
        'include_in_percentage': subject.includeInPercentage ? 1 : 0,
        'include_in_pass_fail': subject.includeInPassFail ? 1 : 0,
        'theme_color': Colors.blue.value,
      });
      for (var j = 0; j < subject.components.length; j++) {
        final c = subject.components[j];
        await db.insert('subject_components', {
          'subject_id': subjectId,
          'component_name': c.name,
          'display_order': j,
          'maximum_marks': c.maximumMarks,
          'passing_marks': 0,
          'is_total': 0,
          'is_editable': 1,
        });
      }
    }

    return domain.CreatedWorkbook(id: workbookId, draft: draft);
  }

  @override
  Future<void> renameWorkbook(int workbookId, String examinationName) async {
    final db = await _db;
    await db.update(
      'workbooks',
      {'class_name': examinationName, 'examination_name': examinationName},
      where: 'id = ?',
      whereArgs: [workbookId],
    );
  }

  @override
  Future<void> deleteWorkbook(int workbookId) async {
    final db = await _db;
    await db.delete('workbooks', where: 'id = ?', whereArgs: [workbookId]);
  }

  @override
  Future<int> createTerm(int workbookId, String termName) async {
    final db = await _db;
    return db.insert('workbook_terms', {
      'workbook_id': workbookId,
      'term_name': termName,
    });
  }

  @override
  Future<List<domain.WorkbookTerm>> getTerms(int workbookId) async {
    final rows = await getWorkbookTerms(workbookId);
    return rows
        .map((t) => domain.WorkbookTerm(id: t.id, workbookId: t.workbookId, name: t.name))
        .toList();
  }

  @override
  Future<void> renameTerm(int termId, String termName) async {
    final db = await _db;
    await db.update(
      'workbook_terms',
      {'term_name': termName},
      where: 'id = ?',
      whereArgs: [termId],
    );
  }

  @override
  Future<void> deleteTerm(int termId) async {
    final db = await _db;
    await db.delete('workbook_terms', where: 'id = ?', whereArgs: [termId]);
  }

  @override
  Future<void> saveTermMark({
    required int workbookId,
    required int termId,
    required int studentId,
    required int componentId,
    String? marks,
  }) async {
    final db = await _db;
    await db.rawInsert('''
      INSERT INTO workbook_marks
        (workbook_id, term_id, student_id, component_id, marks)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(workbook_id, term_id, student_id, component_id)
      DO UPDATE SET marks = excluded.marks
    ''', [workbookId, termId, studentId, componentId, marks ?? '']);
  }

  Future<void> saveTermPromotion({
    required int workbookId,
    required int termId,
    required int studentId,
    required int subjectId,
    required bool isPromoted,
  }) async {
    final db = await _db;
    await db.rawInsert('''
      INSERT INTO workbook_term_promotions
        (workbook_id, term_id, student_id, subject_id, is_promoted)
      VALUES (?, ?, ?, ?, ?)
      ON CONFLICT(workbook_id, term_id, student_id, subject_id)
      DO UPDATE SET is_promoted = excluded.is_promoted
    ''', [workbookId, termId, studentId, subjectId, isPromoted ? 1 : 0]);
  }

  Future<void> saveOverallPromotion({
    required int workbookId,
    required int studentId,
    required bool isPromoted,
  }) async {
    final db = await _db;
    await db.rawInsert('''
      INSERT INTO workbook_overall_promotions
        (workbook_id, student_id, is_promoted)
      VALUES (?, ?, ?)
      ON CONFLICT(workbook_id, student_id)
      DO UPDATE SET is_promoted = excluded.is_promoted
    ''', [workbookId, studentId, isPromoted ? 1 : 0]);
  }

  Future<Map<String, dynamic>?> getWorkbookConfig(int workbookId) async {
    final db = await _db;
    final rows = await db.query('workbooks', where: 'id = ?', whereArgs: [workbookId], limit: 1);
    return rows.isEmpty ? null : rows.first;
  }

  Future<List<TermSetup>> getWorkbookTerms(int workbookId) async {
    final db = await _db;
    final rows = await db.query(
      'workbook_terms',
      where: 'workbook_id = ?',
      whereArgs: [workbookId],
      orderBy: 'id ASC',
    );
    return rows.map(TermSetup.fromMap).toList();
  }

  Future<List<SubjectSetup>> getWorkbookSubjects(int workbookId) async {
    final db = await _db;
    final rows = await db.rawQuery('''
      SELECT s.id AS subject_id, s.subject_name, s.display_order AS subject_order,
             s.maximum_marks AS subject_max, s.passing_marks AS subject_pass,
             s.include_in_percentage, s.include_in_pass_fail, s.theme_color,
             c.id AS component_id, c.component_name, c.display_order AS component_order,
             c.maximum_marks AS comp_max, c.passing_marks AS comp_pass,
             c.is_total, c.is_editable
      FROM workbook_subjects s
      LEFT JOIN subject_components c ON c.subject_id = s.id
      WHERE s.workbook_id = ?
      ORDER BY s.display_order ASC, s.id ASC, c.display_order ASC, c.id ASC
    ''', [workbookId]);

    final subjects = <int, SubjectSetup>{};
    for (final row in rows) {
      final id = row['subject_id'] as int;
      final subject = subjects.putIfAbsent(
        id,
        () => SubjectSetup(
          id: id,
          workbookId: workbookId,
          name: row['subject_name'] as String,
          maxMarks: (row['subject_max'] as num).toDouble(),
          passingMarks: (row['subject_pass'] as num).toDouble(),
          includeInPercentage: (row['include_in_percentage'] as int) == 1,
          includeInPassFail: (row['include_in_pass_fail'] as int) == 1,
          themeColor: Color((row['theme_color'] as int?) ?? Colors.blue.value),
          displayOrder: row['subject_order'] as int,
        ),
      );
      if (row['component_id'] != null) {
        subject.components.add(SubjectComponent(
          id: row['component_id'] as int,
          subjectId: id,
          name: row['component_name'] as String,
          maxMarks: (row['comp_max'] as num).toDouble(),
          passingMarks: (row['comp_pass'] as num).toDouble(),
          isTotal: (row['is_total'] as int) == 1,
          isEditable: (row['is_editable'] as int) == 1,
          displayOrder: row['component_order'] as int,
        ));
      }
    }
    return subjects.values.toList();
  }

  Future<List<StudentRow>> getStudentsWithFullData(int workbookId) async {
    final db = await _db;
    final studentsRaw = await db.query(
      'workbook_students',
      where: 'workbook_id = ?',
      whereArgs: [workbookId],
      orderBy: 'CAST(roll_number AS INTEGER) ASC, roll_number ASC',
    );
    final marksRaw = await db.query('workbook_marks', where: 'workbook_id = ?', whereArgs: [workbookId]);
    final promosRaw = await db.query('workbook_term_promotions', where: 'workbook_id = ?', whereArgs: [workbookId]);
    final overallRaw = await db.query('workbook_overall_promotions', where: 'workbook_id = ?', whereArgs: [workbookId]);

    final students = <int, StudentRow>{};
    for (final s in studentsRaw) {
      students[s['id'] as int] = StudentRow(
        id: s['id'] as int,
        rollNo: s['roll_number'] as String,
        name: s['student_name'] as String,
      );
    }
    for (final m in marksRaw) {
      final student = students[m['student_id'] as int];
      if (student == null) continue;
      final termId = m['term_id'] as int;
      final componentId = m['component_id'] as int;
      student.termMarks.putIfAbsent(termId, () => <dynamic, String>{});
      student.termMarks[termId]![componentId] = m['marks'].toString();
    }
    for (final p in promosRaw) {
      final student = students[p['student_id'] as int];
      if (student == null) continue;
      final termId = p['term_id'] as int;
      final subjectId = p['subject_id'] as int;
      student.termPromotions.putIfAbsent(termId, () => <dynamic, bool>{});
      student.termPromotions[termId]![subjectId] = (p['is_promoted'] as int) == 1;
    }
    for (final p in overallRaw) {
      final student = students[p['student_id'] as int];
      if (student != null) student.isPromotedOverall = (p['is_promoted'] as int) == 1;
    }
    return students.values.toList();
  }

  Future<List<Map<String, dynamic>>> getWorkbookSubjectsWithComponents(int workbookId) async {
    final db = await _db;
    return db.rawQuery('''
      SELECT s.id AS subject_id, s.subject_name, s.display_order AS subject_order,
             s.maximum_marks AS subject_maximum_marks, s.passing_marks AS subject_passing_marks,
             s.include_in_percentage, s.include_in_pass_fail, s.theme_color,
             c.id AS component_id, c.component_name, c.display_order AS component_order,
             c.maximum_marks, c.passing_marks, c.is_total, c.is_editable
      FROM workbook_subjects s
      LEFT JOIN subject_components c ON s.id = c.subject_id
      WHERE s.workbook_id = ?
      ORDER BY s.display_order ASC, s.id ASC, c.display_order ASC, c.id ASC
    ''', [workbookId]);
  }

  Future<List<Map<String, dynamic>>> getMarksForTerm(int workbookId, int termId) async {
    final db = await _db;
    return db.query('workbook_marks', where: 'workbook_id = ? AND term_id = ?', whereArgs: [workbookId, termId]);
  }

  Future<void> updateWorkbookTitle(int workbookId, String title) => renameWorkbook(workbookId, title);

  Future<void> insertLiveStudent(int workbookId, String rollNumber, String name) async {
    final db = await _db;
    await db.insert('workbook_students', {
      'workbook_id': workbookId,
      'student_id': null,
      'roll_number': rollNumber,
      'student_name': name,
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<void> updateLiveStudentInfo(int studentId, String rollNumber, String name) async {
    final db = await _db;
    await db.update('workbook_students', {
      'roll_number': rollNumber,
      'student_name': name,
    }, where: 'id = ?', whereArgs: [studentId]);
  }

  Future<void> deleteLiveStudent(int studentId) async {
    final db = await _db;
    await db.delete('workbook_students', where: 'id = ?', whereArgs: [studentId]);
  }

  Future<void> updateWorkbookSubjects(int workbookId, List<SubjectSetup> subjects) async {
    final db = await _db;
    await db.transaction((txn) async {
      final existingRows = await txn.query('workbook_subjects', where: 'workbook_id = ?', whereArgs: [workbookId]);
      final existingIds = existingRows.map((r) => r['id'] as int).toSet();
      final incomingIds = <int>{};

      for (var i = 0; i < subjects.length; i++) {
        final subject = subjects[i];
        int subjectId;
        if (subject.id != null && existingIds.contains(subject.id)) {
          subjectId = subject.id!;
          incomingIds.add(subjectId);
          await txn.update('workbook_subjects', {
            'subject_name': subject.name,
            'display_order': i,
            'maximum_marks': subject.maxMarks,
            'passing_marks': subject.passingMarks,
            'include_in_percentage': subject.includeInPercentage ? 1 : 0,
            'include_in_pass_fail': subject.includeInPassFail ? 1 : 0,
            'theme_color': subject.themeColor.value,
          }, where: 'id = ?', whereArgs: [subjectId]);
        } else {
          subjectId = await txn.insert('workbook_subjects', {
            'workbook_id': workbookId,
            'subject_name': subject.name,
            'display_order': i,
            'maximum_marks': subject.maxMarks,
            'passing_marks': subject.passingMarks,
            'include_in_percentage': subject.includeInPercentage ? 1 : 0,
            'include_in_pass_fail': subject.includeInPassFail ? 1 : 0,
            'theme_color': subject.themeColor.value,
          });
          subject.id = subjectId;
          subject.workbookId = workbookId;
        }

        final existingComponents = await txn.query('subject_components', where: 'subject_id = ?', whereArgs: [subjectId]);
        final existingComponentIds = existingComponents.map((r) => r['id'] as int).toSet();
        final incomingComponentIds = <int>{};
        if (subject.components.isEmpty) {
          subject.components.add(SubjectComponent(
            name: 'Marks',
            maxMarks: subject.maxMarks,
            passingMarks: subject.passingMarks,
          ));
        }
        for (var j = 0; j < subject.components.length; j++) {
          final component = subject.components[j];
          if (component.id != 0 && existingComponentIds.contains(component.id)) {
            incomingComponentIds.add(component.id);
            await txn.update('subject_components', {
              'component_name': component.name,
              'display_order': j,
              'maximum_marks': component.maxMarks,
              'passing_marks': component.passingMarks,
              'is_total': component.isTotal ? 1 : 0,
              'is_editable': component.isEditable ? 1 : 0,
            }, where: 'id = ?', whereArgs: [component.id]);
          } else {
            final newId = await txn.insert('subject_components', {
              'subject_id': subjectId,
              'component_name': component.name,
              'display_order': j,
              'maximum_marks': component.maxMarks,
              'passing_marks': component.passingMarks,
              'is_total': component.isTotal ? 1 : 0,
              'is_editable': component.isEditable ? 1 : 0,
            });
            component.id = newId;
            component.subjectId = subjectId;
            incomingComponentIds.add(newId);
          }
        }
        for (final oldId in existingComponentIds.difference(incomingComponentIds)) {
          await txn.delete('subject_components', where: 'id = ?', whereArgs: [oldId]);
        }
      }
      for (final oldId in existingIds.difference(incomingIds)) {
        await txn.delete('workbook_subjects', where: 'id = ?', whereArgs: [oldId]);
      }
    });
  }

  Future<int> createSimpleWorkbook(String title) async {
    final db = await _db;
    final now = DateTime.now().toIso8601String();
    final id = await db.insert('workbooks', {
      'academic_year': '',
      'class_name': title,
      'section': '',
      'examination_name': title,
      'student_source_type': 'newList',
      'class_register_id': null,
      'created_at': now,
    });
    await createTerm(id, 'Term 1');
    return id;
  }

  Future<List<Map<String, dynamic>>> fetchAllWorkbooks() async {
    final db = await _db;
    final rows = await db.query('workbooks', orderBy: 'id DESC');
    return rows.map((w) => {
          'id': w['id'],
          'title': w['class_name'],
          'created_at': w['created_at'],
          'examination_name': w['examination_name'],
        }).toList();
  }
}
