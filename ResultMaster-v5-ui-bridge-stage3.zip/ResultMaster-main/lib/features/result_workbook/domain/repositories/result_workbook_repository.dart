import '../entities/result_workbook.dart';

abstract class ResultWorkbookRepository {
  Future<List<Student>> getClassRegisterStudents(int classRegisterId);
  Future<List<WorkbookSummary>> listWorkbooks();
  Future<OpenedWorkbook> openWorkbook(int workbookId);
  Future<CreatedWorkbook> createWorkbook(ResultWorkbookDraft draft);
  Future<void> renameWorkbook(int workbookId, String examinationName);
  Future<void> deleteWorkbook(int workbookId);
  Future<int> createTerm(int workbookId, String termName);
  Future<List<WorkbookTerm>> getTerms(int workbookId);
  Future<void> renameTerm(int termId, String termName);
  Future<void> deleteTerm(int termId);
  Future<void> saveTermMark({
    required int workbookId,
    required int termId,
    required int studentId,
    required int componentId,
    String? marks,
  });
}
