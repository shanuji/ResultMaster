import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/dashboard/presentation/screens/dashboard_screen.dart';
import '../../features/result_workbook/data/repositories/sqlite_result_workbook_repository.dart';
import '../../features/result_workbook/domain/usecases/create_result_workbook.dart';
import '../../features/result_workbook/presentation/pages/new_result_wizard_page.dart';

final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: DashboardScreen.routePath,
    routes: [
      GoRoute(
        path: DashboardScreen.routePath,
        name: DashboardScreen.routeName,
        builder: (context, state) => const DashboardScreen(),
      ),
      GoRoute(
        path: '/new-result',
        name: 'new-result',
        builder: (context, state) => NewResultWizardPage(
          createWorkbook: CreateResultWorkbook(SqliteResultWorkbookRepository()),
        ),
      ),
    ],
  );
});
