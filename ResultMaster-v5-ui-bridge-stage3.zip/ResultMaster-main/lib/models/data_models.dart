import 'package:flutter/material.dart';

class TermSetup {
  int id;
  int workbookId;
  String name;

  TermSetup({required this.id, required this.workbookId, required this.name});

  factory TermSetup.fromMap(Map<String, dynamic> map) => TermSetup(
        id: map['id'] as int,
        workbookId: map['workbook_id'] as int,
        name: map['term_name'] as String,
      );
}

class SubjectComponent {
  int id;
  int subjectId;
  String name;
  double maxMarks;
  double passingMarks;
  bool isTotal;
  bool isEditable;
  int displayOrder;

  String get uiKey => name.replaceAll(' ', '_');

  SubjectComponent({
    this.id = 0,
    this.subjectId = 0,
    required this.name,
    required this.maxMarks,
    this.passingMarks = 0.0,
    this.isTotal = false,
    this.isEditable = true,
    this.displayOrder = 0,
  });
}

class SubjectSetup {
  int? id;
  int? workbookId;
  String name;
  double maxMarks;
  double passingMarks;
  bool includeInPassFail;
  bool includeInPercentage;
  Color themeColor;
  int displayOrder;
  List<SubjectComponent> components;

  SubjectSetup({
    this.id,
    this.workbookId,
    required this.name,
    this.maxMarks = 100.0,
    this.passingMarks = 33.0,
    this.includeInPassFail = true,
    this.includeInPercentage = true,
    this.themeColor = Colors.blue,
    this.displayOrder = 0,
    List<SubjectComponent>? components,
  }) : components = components ?? [];

  void recalculateMaxMarks() {
    if (components.isNotEmpty) {
      maxMarks = components.fold(0.0, (sum, c) => sum + c.maxMarks);
    }
  }
}

class StudentRow {
  int id;
  String rollNo;
  String name;
  bool isPromotedOverall;

  // V5 identity is always the integer component/subject ID. The dynamic key
  // type deliberately permits legacy UI aliases while the repository remains
  // responsible for persistence using integer IDs.
  final Map<int, Map<dynamic, String>> termMarks;
  final Map<int, Map<dynamic, bool>> termPromotions;

  StudentRow({
    this.id = 0,
    required this.rollNo,
    required this.name,
    this.isPromotedOverall = false,
    Map<int, Map<dynamic, String>>? termMarks,
    Map<int, Map<dynamic, bool>>? termPromotions,
  })  : termMarks = termMarks ?? {},
        termPromotions = termPromotions ?? {};

  String getMark(int termId, SubjectComponent component, {String? uiKey}) {
    final marks = termMarks[termId] ?? const <dynamic, String>{};
    return marks[component.id] ?? marks[uiKey ?? component.uiKey] ?? '';
  }

  void setMark(int termId, SubjectComponent component, String value, {String? uiKey}) {
    termMarks.putIfAbsent(termId, () => <dynamic, String>{});
    termMarks[termId]![component.id] = value;
    if (uiKey != null) termMarks[termId]![uiKey] = value;
  }

  bool isPromotedForSubject(int termId, SubjectSetup subject) {
    final promotions = termPromotions[termId] ?? const <dynamic, bool>{};
    return promotions[subject.id] == true || promotions[subject.name] == true;
  }

  void setSubjectPromotion(int termId, SubjectSetup subject, bool value) {
    termPromotions.putIfAbsent(termId, () => <dynamic, bool>{});
    if (subject.id != null) termPromotions[termId]![subject.id!] = value;
    termPromotions[termId]![subject.name] = value;
  }

  String getSubjectMark(int termId, SubjectSetup sub) {
    if (sub.components.isEmpty) {
      final value = termMarks[termId]?[sub.id] ?? termMarks[termId]?[sub.name];
      return value?.toString() ?? '';
    }
    final component = sub.components.firstWhere((c) => !c.isTotal, orElse: () => sub.components.first);
    return getMark(termId, component, uiKey: '${sub.name}_${component.name}');
  }

  String getComponentMark(int termId, SubjectSetup sub, SubjectComponent component) =>
      getMark(termId, component, uiKey: '${sub.name}_${component.name}');

  double getSubjectScore(int termId, SubjectSetup sub) {
    if (sub.components.isEmpty) {
      return double.tryParse(
            (termMarks[termId]?[sub.id] ?? termMarks[termId]?[sub.name] ?? '').toString(),
          ) ??
          0.0;
    }
    double total = 0.0;
    for (final c in sub.components) {
      total += double.tryParse(getMark(termId, c, uiKey: '${sub.name}_${c.name}')) ?? 0.0;
    }
    return total;
  }

  bool isSubjectAttempted(int termId, SubjectSetup sub) {
    if (sub.components.isEmpty) {
      final val = (termMarks[termId]?[sub.id] ?? termMarks[termId]?[sub.name] ?? '')
          .toString()
          .trim()
          .toUpperCase();
      return val.isNotEmpty && (double.tryParse(val) != null || val == 'A' || val == 'AB');
    }
    for (final c in sub.components) {
      final val = getMark(termId, c, uiKey: '${sub.name}_${c.name}').trim().toUpperCase();
      if (val.isEmpty || (double.tryParse(val) == null && val != 'A' && val != 'AB')) return false;
    }
    return true;
  }

  bool isSubjectPassed(int termId, SubjectSetup sub) {
    if (isPromotedForSubject(termId, sub)) return true;

    if (sub.components.isNotEmpty) {
      for (final c in sub.components) {
        if (c.passingMarks > 0) {
          final score = double.tryParse(getMark(termId, c, uiKey: '${sub.name}_${c.name}')) ?? 0.0;
          if (score < c.passingMarks) return false;
        }
      }
    }
    return getSubjectScore(termId, sub) >= sub.passingMarks;
  }
}
