import 'package:flutter/material.dart';
import '../models/data_models.dart';
import '../features/result_workbook/data/repositories/sqlite_result_workbook_repository.dart';

class FinalResultScreen extends StatefulWidget {
  final int workbookId;
  final String workbookTitle;
  const FinalResultScreen({super.key, required this.workbookId, required this.workbookTitle});

  @override
  State<FinalResultScreen> createState() => _FinalResultScreenState();
}

class _FinalResultScreenState extends State<FinalResultScreen> {
  List<TermSetup> _terms = [];
  List<StudentRow> _students = [];
  bool _isLoading = true;
  final SqliteResultWorkbookRepository _repository = SqliteResultWorkbookRepository();

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final terms = await _repository.getWorkbookTerms(widget.workbookId);
    final students = await _repository.getStudentsWithFullData(widget.workbookId);
    if (!mounted) return;
    setState(() { _terms = terms; _students = students; _isLoading = false; });
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    
    return Scaffold(
      appBar: AppBar(title: Text('${widget.workbookTitle} - Final Result'), backgroundColor: Colors.green[100]),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.construction, size: 80, color: Colors.grey),
            const SizedBox(height: 16),
            const Text('Final Multi-Term Spanning Grid coming up next!', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('Successfully loaded ${_terms.length} terms and ${_students.length} students.', style: const TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}
